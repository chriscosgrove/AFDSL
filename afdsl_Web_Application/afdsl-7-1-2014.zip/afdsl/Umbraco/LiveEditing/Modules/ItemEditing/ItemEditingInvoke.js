﻿//this is simply used for live editing in order to invoke a method from a previously lazy loaded script;
//alert("ItemEditingInvoke: " + initializeGlobalItemEditing);
initializeGlobalItemEditing();