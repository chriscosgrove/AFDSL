﻿jQuery('.selectskin').click(function () {

    jQuery('#skinupdateinprogress').show();

    jQuery('#skins').hide();

    jQuery('#localSkinsContainer').hide();
});